
<ul class="nav nav-treeview">
    <li class="nav-item">
        <a href="<?php echo e(route('users.index')); ?>"
           class="nav-link <?php echo e(Request::is('users*') ? 'active' : ''); ?>">
            <i class="far fa-circle nav-icon"></i>
            <p>Manage User</p>
        </a>
    </li>

    <li class="nav-item">
        <a href="<?php echo e(route('roles.index')); ?>"
           class="nav-link <?php echo e(Request::is('roles*') ? 'active' : ''); ?>">
            <i class="far fa-circle nav-icon"></i>
            <p>Manage Role</p>
        </a>
    </li>

</ul>
<li class="nav-item">
    <a href="<?php echo e(route('users.index')); ?>"
       class="nav-link <?php echo e(Request::is('users*') ? 'active' : ''); ?>">
        <p>Manage User</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('roles.index')); ?>"
       class="nav-link <?php echo e(Request::is('roles*') ? 'active' : ''); ?>">
        <p>Manage Role</p>
    </a>
</li>

<li class="nav-item">
    <a href="<?php echo e(route('kategoris.index')); ?>"
       class="nav-link <?php echo e(Request::is('kategoris*') ? 'active' : ''); ?>">
        <p>Kategoris</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('beritas.index')); ?>"
       class="nav-link <?php echo e(Request::is('beritas*') ? 'active' : ''); ?>">
        <p>Beritas</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('slides.index')); ?>"
       class="nav-link <?php echo e(Request::is('slides*') ? 'active' : ''); ?>">
        <p>Slides</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('abouts.index')); ?>"
       class="nav-link <?php echo e(Request::is('abouts*') ? 'active' : ''); ?>">
        <p>Abouts</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('media.index')); ?>"
       class="nav-link <?php echo e(Request::is('media*') ? 'active' : ''); ?>">
        <p>Media</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('daerahs.index')); ?>"
       class="nav-link <?php echo e(Request::is('daerahs*') ? 'active' : ''); ?>">
        <p>Daerahs</p>
    </a>
</li>



<li class="nav-item">
    <a href="<?php echo e(route('beritaDaerahs.index')); ?>"
       class="nav-link <?php echo e(Request::is('beritaDaerahs*') ? 'active' : ''); ?>">
        <p>Berita Daerahs</p>
    </a>
</li>



<li class="nav-item">
    <a href="<?php echo e(route('iklans.index')); ?>"
       class="nav-link <?php echo e(Request::is('iklans*') ? 'active' : ''); ?>">
        <p>Iklans</p>
    </a>
</li>




<li class="nav-item">
    <a href="<?php echo e(route('komens.index')); ?>"
       class="nav-link <?php echo e(Request::is('komens*') ? 'active' : ''); ?>">
        <p>Komens</p>
    </a>
</li>


<li class="nav-item">
    <a href="<?php echo e(route('komenDaerahs.index')); ?>"
       class="nav-link <?php echo e(Request::is('komenDaerahs*') ? 'active' : ''); ?>">
        <p>Komen Daerahs</p>
    </a>
</li>


<?php /**PATH C:\xampp\htdocs\berita\resources\views/layouts/menu.blade.php ENDPATH**/ ?>