
<?php $__env->startSection('content'); ?>

<?php $brt = app('App\Models\Berita'); ?>
<?php $brtD = app('App\Models\BeritaDaerah'); ?>
    <section class="blog_area section-padding">
        <div class="container">
            <div class="row">
                <div class="col">
                    <div class="card">
                        <div class="card-header">
                            <h3><?php echo $kategoris->nama; ?></h3>
                        </div>
                    </div>
                </div>
            </div>
            <br>
            <div class="row">
                <div class="col-lg-8 mb-5 mb-lg-0">
                    <div class="blog_left_sidebar">
                        <?php $__currentLoopData = $beritas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="blog_item">
                                <div class="blog_item_img">
                                    <img class="card-img rounded-0"
                                         src="<?php echo asset('data/berita'); ?>/<?php echo $berita->foto; ?>"
                                         alt="">
                                    <a href="#" class="blog_item_date">
                                        <h3><?php echo date_format($berita->created_at,"d"); ?></h3>
                                        <p><?php echo date_format($berita->created_at,"M"); ?></p>
                                    </a>
                                </div>

                                <div class="blog_details">
                                    <a class="d-inline-block" href="<?php echo route('kategori.show',$berita->id); ?>">
                                        <h2><?php echo $berita->judul; ?></h2>
                                    </a>

                                    <ul class="blog-info-link">
                                        <li><a href="#"><i class="fa fa-user"></i> <?php echo $kategoris->nama; ?></a>
                                        </li>
                                        <li><a href="#"><i class="fa fa-eye"></i> <?php echo $berita->view; ?></a></li>
                                    </ul>
                                </div>

                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <br>

                <div class="col-lg-4">
                    <?php echo $__env->make('layouts_user.right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts_user.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\berita\resources\views/user/kategori/index.blade.php ENDPATH**/ ?>