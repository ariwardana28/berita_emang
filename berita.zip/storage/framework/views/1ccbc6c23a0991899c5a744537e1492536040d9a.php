

<?php $__env->startSection('content'); ?>
    <?php $brt = app('App\Models\Berita'); ?>

    <section class="blog_area single-post-area section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 posts-list">
                    <div class="single-post">
                        <div class="feature-img">
                        </div>
                        <div class="blog_details">
                            <h2><?php echo $tentang->judul; ?>

                            </h2>
                            <ul class="blog-info-link mt-3 mb-4">
                                <li><a href="#"><?php echo $tentang->nama; ?></a></li>
                            </ul>
                            <p class="excert">
                                <?php echo $tentang->text; ?>

                            </p>

                        </div>
                    </div>
                </div>

                <div class="col-lg-4">
                    <?php echo $__env->make('layouts_user.right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts_user.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\berita\resources\views/user/tentang/index.blade.php ENDPATH**/ ?>