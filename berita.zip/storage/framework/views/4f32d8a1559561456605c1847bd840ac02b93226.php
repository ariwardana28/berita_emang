<!-- Daerah Id Field -->
<div class="col-sm-12">
    <?php echo Form::label('daerah_id', 'Daerah Id:'); ?>

    <p><?php echo e($beritaDaerah->daerah_id); ?></p>
</div>

<!-- Judul Field -->
<div class="col-sm-12">
    <?php echo Form::label('judul', 'Judul:'); ?>

    <p><?php echo e($beritaDaerah->judul); ?></p>
</div>

<!-- Foto Field -->
<div class="col-sm-12">
    <?php echo Form::label('foto', 'Foto:'); ?>

    <p>{
        <img src="<?php echo asset('data/beritaDaerah'); ?>/<?php echo $beritaDaerah->foto; ?>" style="width: 20%">
    </p>
</div>

<!-- Berita Field -->
<div class="col-sm-12">
    <?php echo Form::label('berita', 'Berita:'); ?>

    <p><?php echo $beritaDaerah->berita; ?></p>
</div>

<!-- Created At Field -->
<div class="col-sm-12">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($beritaDaerah->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="col-sm-12">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($beritaDaerah->updated_at); ?></p>
</div>

<?php /**PATH C:\xampp\htdocs\berita\resources\views/berita_daerahs/show_fields.blade.php ENDPATH**/ ?>