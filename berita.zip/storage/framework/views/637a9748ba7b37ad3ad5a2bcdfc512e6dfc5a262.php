<!-- Nama Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('nama', 'Nama:'); ?>

    <?php echo Form::text('nama', null, ['class' => 'form-control']); ?>

</div><?php /**PATH C:\xampp\htdocs\berita\resources\views/daerahs/fields.blade.php ENDPATH**/ ?>