<?php $brt = app('App\Models\Berita'); ?>
<?php $ktgr = app('App\Models\Kategori'); ?>
<?php
    $max = $brt->max('view');
    $berita = $brt->where('view',$max)->first();
    $trandings = $brt->where('view','<',$max)->limit(4)->get();

    $kategoris = $ktgr->all();
?>
<div class="trending-area fix">
    <div class="container">
        <div class="trending-main">
            <!-- Trending Tittle -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="trending-tittle">
                        <strong>Trending now</strong>
                        <!-- <p>Rem ipsum dolor sit amet, consectetur adipisicing elit.</p> -->
                        <div class="trending-animated">
                            <ul id="js-news" class="js-hidden">
                                <?php $__currentLoopData = $trandings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tranding): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="news-item"><?php echo $tranding->judul; ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg">
                    <!-- Trending Top -->
                    <div class="trending-top mb-30">
                        <div class="trend-top-img">
                            <img src="<?php echo asset('data/berita'); ?>/<?php echo $berita->foto; ?>" alt="">
                            <div class="trend-top-cap">
                                <span><?php echo $berita->Kategori->nama; ?></span>
                                <h2 style="width:90%"><a href="details.html"><?php echo $berita->judul; ?></a></h2>
                            </div>
                        </div>
                    </div>
                    <!-- Trending Bottom -->
                    <div class="trending-bottom">
                        <div class="row">
                            <?php $__currentLoopData = $trandings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tranding): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-3">
                                    <div class="single-bottom mb-35">
                                        <div class="trend-bottom-img mb-30">
                                            <img src="<?php echo asset('data/berita'); ?>/<?php echo $tranding->foto; ?>"  alt="" style="max-height: 100px">
                                        </div>
                                        <div class="trend-bottom-cap">
                                            <span class="color1"><?php echo $tranding->Kategori->nama; ?></span>
                                            <h4><a href="details.html"><?php echo $tranding->judul; ?></a>
                                            </h4>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                                
                                    
                                        
                                    
                                    
                                        
                                        
                                                    
                                    
                                
                            
                            
                                
                                    
                                        
                                    
                                    
                                        
                                        
                                    
                                
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\berita\resources\views/user/tran.blade.php ENDPATH**/ ?>