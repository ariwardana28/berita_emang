<!-- Foto Field -->
<div class="col-sm-12">
    <?php echo Form::label('foto', 'Foto:'); ?>

    <p>
        <img src="<?php echo asset('data/iklan'); ?>/<?php echo $iklan->foto; ?>" style="width: 20%">
    </p>
</div>

<!-- Created At Field -->
<div class="col-sm-12">
    <?php echo Form::label('created_at', 'Created At:'); ?>

    <p><?php echo e($iklan->created_at); ?></p>
</div>

<!-- Updated At Field -->
<div class="col-sm-12">
    <?php echo Form::label('updated_at', 'Updated At:'); ?>

    <p><?php echo e($iklan->updated_at); ?></p>
</div>

<?php /**PATH C:\xampp\htdocs\berita\resources\views/iklans/show_fields.blade.php ENDPATH**/ ?>