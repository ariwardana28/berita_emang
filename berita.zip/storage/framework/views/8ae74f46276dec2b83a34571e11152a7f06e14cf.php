

<?php $__env->startSection('content'); ?>

    <?php $brt = app('App\Models\Berita'); ?>
    <?php $kom = app('App\Models\KomenDaerah'); ?>

    <meta property="og:title" content="San Roque 2014 Pollos"/>
    <meta property="og:description" content="Programa de fiestas"/>
    <meta property="og:image" content="<?php echo asset('data/beritaDaerah'); ?>/<?php echo $beritaDaerah->foto; ?>"/>

    <section class="blog_area single-post-area section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 posts-list">
                    <div class="single-post">
                        <div class="feature-img">
                            <img class="img-fluid" src="<?php echo asset('data/beritaDaerah'); ?>/<?php echo $beritaDaerah->foto; ?>"
                                 alt="">
                        </div>
                        <div class="blog_details">
                            <h2><?php echo $beritaDaerah->judul; ?>

                            </h2>
                            <ul class="blog-info-link mt-3 mb-4">
                                <li><a href="#"><i class="fa fa-user"></i> <?php echo $beritaDaerah->Daerah->nama; ?></a></li>
                                <li><a href="#"><i class="fa fa-eye"></i> <?php echo $beritaDaerah->view; ?> View</a></li>
                            </ul>
                            <p class="excert">
                                <?php echo $beritaDaerah->berita; ?>

                            </p>

                        </div>
                    </div>
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    

                    <div class="comments-area">
                        <?php
                            $komens = $kom->where('berita_daerah_id',$berita_daerah_id)->get();
                            $count = $kom->where('berita_daerah_id',$berita_daerah_id)->count('berita_daerah_id');
                        ?>
                        <h4><?php echo $count; ?> Comments</h4>
                        <?php $__currentLoopData = $komens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="comment-list">
                                <div class="single-comment justify-content-between d-flex">
                                    <div class="user justify-content-between d-flex">
                                        <div class="desc">
                                            <p class="comment">
                                                <?php echo $komen->komen; ?>

                                            </p>
                                            <div class="d-flex justify-content-between">
                                                <div class="d-flex align-items-center">
                                                    <h5>
                                                        <a href="#"><?php echo $komen->nama; ?></a>
                                                    </h5>
                                                    <p class="date"><?php echo date_format($komen->created_at,"M d, Y"); ?>

                                                        at <?php echo date_format($komen->created_at,"h:i"); ?> </p>
                                                </div>
                                                <div class="reply-btn">
                                                    <a href="#" class="btn-reply text-uppercase"></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="comment-form">
                        <h4>Leave a Reply</h4>
                        <form class="form-contact comment_form" action="<?php echo route('komenDaerahs.store'); ?>"
                              method="post"
                              id="commentForm">
                            <?php echo csrf_field(); ?>
                            <div class="row">

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <input class="form-control" name="nama" id="name" type="text"
                                               placeholder="Name">
                                        <input class="form-control" name="berita_daerah_id" id="name" type="hidden"
                                               value="<?php echo $berita_daerah_id; ?>" placeholder="Name">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <input class="form-control" name="email" id="email" type="email"
                                               placeholder="Email">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                              <textarea class="form-control w-100" name="komen" id="comment" cols="30" rows="9"
                                        placeholder="Write Comment"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="button button-contactForm btn_1 boxed-btn">Send Message
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="col-lg-4">
                    <?php echo $__env->make('layouts_user.right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts_user.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\berita\resources\views/user/daerah/show.blade.php ENDPATH**/ ?>