<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
<script>

    tinymce.init({
        selector: 'textarea#default',
    });
</script>
<!-- Judul Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('judul', 'Judul:'); ?>

    <?php echo Form::text('judul', null, ['class' => 'form-control']); ?>

</div>

<!-- Text Field -->
<div class="form-group col-sm-12">
    <?php echo Form::label('text', 'Text:'); ?>

    
    <?php echo Form::textarea('text', null, ['class' => 'form-control','id' => 'default']); ?>


</div><?php /**PATH C:\xampp\htdocs\berita\resources\views/abouts/fields.blade.php ENDPATH**/ ?>