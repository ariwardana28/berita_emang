<!-- Foto Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('foto', 'Foto:'); ?>

    <div class="input-group">
        <div class="custom-file">
            <?php echo Form::file('foto', ['class' => 'custom-file-input']); ?>

            <?php echo Form::label('foto', 'Choose file', ['class' => 'custom-file-label']); ?>

        </div>
    </div>
</div>
<div class="clearfix"></div>


<!-- Status Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('status', 'Status:'); ?>


    <?php echo Form::select('status', ['0' => 'Hidden', '1' => 'Overview'], null, ['class' => 'form-control','placeholder' => 'Pilih Status']); ?>

</div><?php /**PATH C:\xampp\htdocs\berita\resources\views/slides/fields.blade.php ENDPATH**/ ?>