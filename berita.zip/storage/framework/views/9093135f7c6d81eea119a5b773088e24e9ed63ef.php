<?php $__env->startSection('content'); ?>
    <!-- Trending Area Start -->
   <?php echo $__env->make('layouts_user.tran', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Whats New End -->

    <!--   Weekly2-News start -->
    <?php echo $__env->make('layouts_user.kategori', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- End Weekly-News -->

</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts_user.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\berita\resources\views/welcome.blade.php ENDPATH**/ ?>