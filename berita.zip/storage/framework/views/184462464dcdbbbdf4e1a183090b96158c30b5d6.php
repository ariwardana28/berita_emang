<div class="table-responsive">
    <table class="table" id="komenDaerahs-table">
        <thead>
        <tr>
            <th>Berita Daerah Id</th>
        <th>Nama</th>
        <th>Email</th>
        <th>Komen</th>
            <th colspan="3">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $komenDaerahs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komenDaerah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($komenDaerah->berita_daerah_id); ?></td>
            <td><?php echo e($komenDaerah->nama); ?></td>
            <td><?php echo e($komenDaerah->email); ?></td>
            <td><?php echo e($komenDaerah->komen); ?></td>
                <td width="120">
                    <?php echo Form::open(['route' => ['komenDaerahs.destroy', $komenDaerah->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo e(route('komenDaerahs.show', [$komenDaerah->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-eye"></i>
                        </a>
                        <a href="<?php echo e(route('komenDaerahs.edit', [$komenDaerah->id])); ?>"
                           class='btn btn-default btn-xs'>
                            <i class="far fa-edit"></i>
                        </a>
                        <?php echo Form::button('<i class="far fa-trash-alt"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\berita\resources\views/komen_daerahs/table.blade.php ENDPATH**/ ?>