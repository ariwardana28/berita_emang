<!-- Kategori Id Field -->
<div class="col-sm-12">
    <?php echo Form::label('kategori_id', 'Kategori Id:'); ?>

    <p><?php echo e($berita->Kategori->nama); ?></p>
</div>

<!-- Judul Field -->
<div class="col-sm-12">
    <?php echo Form::label('judul', 'Judul:'); ?>

    <p><?php echo e($berita->judul); ?></p>
</div>


<!-- Foto Field -->
<div class="col-sm-12">
    <?php echo Form::label('foto', 'Foto:'); ?>

    <p>
        <img src="<?php echo asset('data/berita'); ?>/<?php echo $berita->foto; ?>" style="width: 20%">
    </p>
</div>


<!-- Berita Field -->
<div class="col-sm-12">
    <?php echo Form::label('berita', 'Berita:'); ?>

    <p><?php echo $berita->berita; ?></p>
</div>



    
    




    
    


<?php /**PATH C:\xampp\htdocs\berita\resources\views/beritas/show_fields.blade.php ENDPATH**/ ?>