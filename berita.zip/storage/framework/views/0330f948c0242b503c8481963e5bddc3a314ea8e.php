<!-- Judul Field -->
<div class="col-sm-12">
    <?php echo Form::label('judul', 'Judul:'); ?>

    <p><?php echo e($about->judul); ?></p>
</div>

<!-- Text Field -->
<div class="col-sm-12">
    <?php echo Form::label('text', 'Keterangan:'); ?>

    <p><?php echo $about->text; ?></p>
</div>



    
    




    
    


<?php /**PATH C:\xampp\htdocs\berita\resources\views/abouts/show_fields.blade.php ENDPATH**/ ?>