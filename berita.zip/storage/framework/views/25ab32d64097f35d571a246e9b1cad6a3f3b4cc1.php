<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/6/tinymce.min.js" referrerpolicy="origin"></script>
<script>

    tinymce.init({
        selector: 'textarea#default',
    });
</script>

<!-- Kategori Id Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('kategori_id', 'Kategori Id:'); ?>


    <?php echo e(Form::select('kategori_id', $kategori, null, ['class' => 'form-control', 'placeholder' => '--Pilih Kategori --'])); ?>

</div>

<!-- Judul Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('judul', 'Judul:'); ?>

    <?php echo Form::text('judul', null, ['class' => 'form-control']); ?>

</div>

<!-- Foto Field -->
<div class="form-group col-sm-6">
    <?php echo Form::label('foto', 'Foto:'); ?>

    <div class="input-group">
        <div class="custom-file">
            <?php echo Form::file('foto', ['class' => 'custom-file-input']); ?>

            <?php echo Form::label('foto', 'Choose file', ['class' => 'custom-file-label']); ?>

        </div>
    </div>
</div>

<!-- Berita Field -->
<div class="form-group col-sm-12 col-lg-12">
    <?php echo Form::label('berita', 'Berita:'); ?>

    <?php echo Form::textarea('berita', null, ['class' => 'form-control','id' => 'default']); ?>

</div>


<div class="clearfix"></div>
<?php /**PATH C:\xampp\htdocs\berita\resources\views/beritas/fields.blade.php ENDPATH**/ ?>