@extends('layouts_user.menu')

@section('content')
    <!-- Trending Area Start -->
   @include('layouts_user.tran')
    <!-- Whats New End -->

    <!--   Weekly2-News start -->
    @include('layouts_user.kategori')

    <!-- End Weekly-News -->

</main>

@endsection
